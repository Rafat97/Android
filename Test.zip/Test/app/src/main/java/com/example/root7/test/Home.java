package com.example.root7.test;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;


public class Home extends AppCompatActivity implements ConnectivityReceiver.ConnectivityReceiverListener {

   public static TextView myText;

    public boolean internet(){
        boolean value = false;
        try {
            Socket soc = new Socket();
            SocketAddress adds = new InetSocketAddress("8.8.8.8",53);
            soc.connect(adds,1500);
            soc.close();
            value = true;
        }catch (Exception e){
            value = false;
            Log.i("EX",e.toString());
        }
        return value;
    }

    public boolean isConnectedNet(){

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnect =  activeNetwork != null && activeNetwork.isConnected();
        return isConnect;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        myText = (TextView) findViewById(R.id.textView);



        Thread th = new Thread(new Runnable() {

            @Override
            public void run() {
                boolean val = true;
                while (val) {
                    try {
                        Check_internet c = new Check_internet(Home.this);
                        c.execute();
                        int i = c.doInBackground();
                        if (i == 0){
                            Intent homeDo;
                            homeDo = new Intent(Home.this, NoInternet_Error.class);
                            startActivity(homeDo);
                            finish();
                            val = false;
                        }
                        System.out.println(i);
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        th.start();


    }

    @Override
    protected void onResume() {
        super.onResume();

        //MyApplication.getInstance().setConnectivityListener(this);
    }

    public void isCheck(){
        boolean val = ConnectivityReceiver.isConnected();
        tost(val);
    }

    public void tost(boolean val){
        if (val)
        {
            Toast.makeText(getApplicationContext(), "OK ", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(getApplicationContext(), " FAIL ", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onNetworkConnectionChanged(boolean isConnected) {
        tost(isConnected);
    }
}
