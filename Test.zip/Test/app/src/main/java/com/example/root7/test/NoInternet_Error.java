package com.example.root7.test;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class NoInternet_Error extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_internet__error);
        Thread th = new Thread(new Runnable() {

            @Override
            public void run() {
                boolean val = true;
                while (val) {
                    try {
                        Check_internet c = new Check_internet(NoInternet_Error.this);
                        c.execute();
                        int i = c.doInBackground();
                        if (i == 1){
                            Intent homeDo;
                            homeDo = new Intent(NoInternet_Error.this, Home.class);
                            startActivity(homeDo);
                            finish();
                            val = false;
                        }
                        System.out.println(i);
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        th.start();

    }
}
