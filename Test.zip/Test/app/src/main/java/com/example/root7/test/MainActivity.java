package com.example.root7.test;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;
import com.example.root7.test.Check_internet;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

public class MainActivity extends AppCompatActivity {

    public Check_internet chk;

    public AlertDialog.Builder BuiltDiolog(Context context){
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("No Internet Connection !!");
        builder.setMessage("Open the Mobile Data Or WI-Fi & Please ,OK to Exit Program ");
        builder.setPositiveButton("OK",new DialogInterface.OnClickListener(){

            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        return  builder;

    }

    public boolean isConnectedNet(){

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean isConnect =  activeNetwork != null && activeNetwork.isConnected();
        return isConnect;

    }




        public boolean internet(){
            boolean value = false;
            try {
                Socket soc = new Socket();
                SocketAddress adds = new InetSocketAddress("8.8.8.8",53);
                soc.connect(adds,1500);
                soc.close();
                value = true;
            }catch (Exception e){
                value = false;
            }
            return value;
        }


     public void check_Connection() {
        chk = new Check_internet(this);
        chk.execute();
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN , WindowManager.LayoutParams.FLAG_FULLSCREEN);


        setContentView(R.layout.activity_main);
        check_Connection();


        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {


                    boolean val = true;
                    while (val) {
                        Thread.sleep(2000);
                        if (isConnectedNet()) {


                            if (internet()) {

                                Log.i("TRUE", "Internet Connect");

                                Intent homeDo;
                                homeDo = new Intent(MainActivity.this, Home.class);
                                startActivity(homeDo);
                                finish();
                                val = false;



                            } else {
                                Log.i("TRUE", "Not Internet() Connecterd");
                            }


                        } else {
                            Log.i("TRUE", "Not Connecterd");
                        }
                    }

                }catch (Exception e){
                    System.out.println(e);
                }
            }
        });
        t.start();


    }

}
